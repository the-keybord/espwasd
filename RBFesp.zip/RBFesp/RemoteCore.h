#pragma once
#include <Arduino.h>

/****************************************************************
 *  RBFesp - RemoteCore.h
 *  --------------------------------------------------------------
 *  Clean, minimal core classes for ESP32 Remote Controller:
 *  - KeyEvent: passed to onButton() with key, pressed, released
 *  - RemoteDisplay: controls display1 and display2
 *  - RemoteController: tracks connection and held key states
 ****************************************************************/

// Forward declarations of internal transmitter packet functions (defined in RBFesp.ino)
void _sendRemotePacket(int displayTarget, const String &text);
void _sendRemoteRaw(const String &packet);

// ==============================================================
//  KeyEvent Class
// ==============================================================
class KeyEvent {
public:
  char key;        // The button character ('1'-'4', 'Q'-'R', 'A'-'F', 'Z'-'V')
  bool pressed;    // true when button is pushed down
  bool released;   // true when button is released
  char action;     // '+' for press, '-' for release

  KeyEvent(char k = ' ', bool isPress = true) {
    key = k;
    pressed = isPress;
    released = !isPress;
    action = isPress ? '+' : '-';
  }

  // Implicit conversion to char (allows: if (event == 'A'))
  operator char() const { return key; }

  // Comparison operators for easy student writing
  bool operator==(char c) const { return key == c; }
  bool operator!=(char c) const { return key != c; }

  // Helper methods
  bool is(char k) const { return key == k; }
  bool isPressed(char k) const { return key == k && pressed; }
  bool isReleased(char k) const { return key == k && released; }
};

// ==============================================================
//  RemoteDisplay Class
//  Provides simple print(...) methods for display1 and display2
// ==============================================================
class RemoteDisplay {
private:
  int _id;

public:
  RemoteDisplay(int id) : _id(id) {}

  int getId() const { return _id; }

  // Send strings
  void print(const String &text) {
    _sendRemotePacket(_id, text);
  }

  void print(const char* text) {
    _sendRemotePacket(_id, String(text));
  }

  void print(char c) {
    _sendRemotePacket(_id, String(c));
  }

  // Send numbers
  void print(int val) {
    _sendRemotePacket(_id, String(val));
  }

  void print(unsigned int val) {
    _sendRemotePacket(_id, String(val));
  }

  void print(long val) {
    _sendRemotePacket(_id, String(val));
  }

  void print(unsigned long val) {
    _sendRemotePacket(_id, String(val));
  }

  void print(float val, int decimals = 2) {
    _sendRemotePacket(_id, String(val, decimals));
  }

  void print(double val, int decimals = 2) {
    _sendRemotePacket(_id, String(val, decimals));
  }

  void print(bool val) {
    _sendRemotePacket(_id, val ? "1" : "0");
  }

  // Two-parameter print for label + value
  template <typename T1, typename T2>
  void print(const T1 &prefix, const T2 &value) {
    _sendRemotePacket(_id, String(prefix) + String(value));
  }

  // println aliases
  void println(const String &text) { print(text); }
  void println(const char* text)   { print(text); }
  void println(int val)            { print(val); }
  void println(float val)          { print(val); }
  void println()                   { clear(); }

  // Clear display line
  void clear() {
    _sendRemotePacket(_id, "");
  }

  // Assignment operator: display1 = "Hello"; or display1 = 42;
  RemoteDisplay& operator=(const String &text) { print(text); return *this; }
  RemoteDisplay& operator=(const char* text)   { print(text); return *this; }
  RemoteDisplay& operator=(int val)            { print(val); return *this; }
  RemoteDisplay& operator=(float val)          { print(val); return *this; }
};

// ==============================================================
//  RemoteController Class
//  Tracks overall remote status (connection, held keys)
// ==============================================================
class RemoteController {
private:
  bool _connected;
  bool _keyState[256];

public:
  RemoteController() : _connected(false) {
    for (int i = 0; i < 256; i++) {
      _keyState[i] = false;
    }
  }

  bool isConnected() const {
    return _connected;
  }

  bool isKeyDown(char key) const {
    unsigned char idx = (unsigned char)key;
    return _keyState[idx];
  }

  bool isPressed(char key) const {
    return isKeyDown(key);
  }

  void _setConnected(bool conn) {
    _connected = conn;
    if (!conn) {
      for (int i = 0; i < 256; i++) {
        _keyState[i] = false;
      }
    }
  }

  void _setKeyState(char key, bool pressed) {
    unsigned char idx = (unsigned char)key;
    _keyState[idx] = pressed;
  }
};

// Global objects available throughout the project
extern RemoteDisplay display1;
extern RemoteDisplay display2;
extern RemoteController remote;
