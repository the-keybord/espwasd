#pragma once
#include "RemoteCore.h"

void userSetup() {

}

void onButton(KeyEvent event) {

  if (event == 'W')
  {
    if(event.isPressed('W'))
    {
      Serial.println("Hello");
    }
    else
    {
      Serial.println("Goodbye");
    }
  }

}
